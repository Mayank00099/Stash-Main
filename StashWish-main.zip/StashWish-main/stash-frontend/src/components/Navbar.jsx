import React, { useState } from "react";
import { Link } from "react-router-dom";
import styles from "./Navbar.module.css";

const Navbar = () => {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <nav className={styles.navbar}>
      <div className={styles.logo}>StashWish</div>
      <div>
        <button
          className={styles.menuToggle}
          onClick={() => setMenuOpen(!menuOpen)}
        >
          ☰
        </button>
      </div>

      <ul className={`${styles.navLinks} ${menuOpen ? styles.active : ""}`}>
        <li>
          <Link to="/" onClick={() => setMenuOpen(false)}>
            Dashboard
          </Link>
        </li>
        <li>
          <Link to="/wishlist" onClick={() => setMenuOpen(false)}>
            Wishlist
          </Link>
        </li>
        <li>
          <Link to="/stake" onClick={() => setMenuOpen(false)}>
            Stake
          </Link>
        </li>
        <li>
          <Link to="/profile" onClick={() => setMenuOpen(false)}>
            Profile
          </Link>
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;
