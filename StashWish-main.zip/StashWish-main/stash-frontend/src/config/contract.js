import ABI from "./StashWishABI.json";

const contractConfig = {
  address: "0x6CE04F6F75B6114A1c591fb3AC045F5ED0313ef2",
  abi: ABI,
};

export default contractConfig;
