import { ethers } from "ethers";

export const getReadProvider = () => {
  return new ethers.BrowserProvider(window.ethereum);
};
