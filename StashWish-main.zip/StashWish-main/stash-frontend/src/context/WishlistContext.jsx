import React, { createContext, useEffect, useState } from "react";
import { ethers } from "ethers";
import contractConfig from "../config/contract";

export const WishlistContext = createContext();

export const WishlistProvider = ({ children }) => {

const [wishlistItems, setWishlistItems] = useState([]);
const [loading, setLoading] = useState(false);
const [error, setError] = useState("");


const getSignerAndContract = async () => {
if (!window.ethereum) throw new Error("MetaMask not found");


await window.ethereum.request({ method: "eth_requestAccounts" });

const provider = new ethers.BrowserProvider(window.ethereum);
const signer = await provider.getSigner();

const contract = new ethers.Contract(
  contractConfig.address,
  contractConfig.abi,
  signer
);

return { signer, contract };


};


const fetchWishlist = async () => {
try {
setLoading(true);
setError("");


  const { signer, contract } = await getSignerAndContract();
  const userAddress = await signer.getAddress();

  console.log("Fetching wishlist for:", userAddress);

  const items = await contract.getWishlist(userAddress);

  const formatted = items.map((item) => ({
    name: item.name,
    flair: item.flair,
    targetAmount: Number(ethers.formatEther(item.targetAmount)),
    savedAmount: Number(ethers.formatEther(item.savedAmount)),
    unlocked: item.unlocked,
  }));

  console.log("Formatted wishlist:", formatted);

  setWishlistItems(formatted);

} catch (err) {
  console.error("FETCH ERROR:", err);
  setError("Failed to load wishlist");
} finally {
  setLoading(false);
}


};


const addWishlistItem = async (name, flair, targetAmount) => {
try {
setLoading(true);
setError("");


  const { contract } = await getSignerAndContract();

  const tx = await contract.addWishlistItem(
    name,
    flair,
    ethers.parseEther(targetAmount.toString())
  );

  console.log("Add tx:", tx.hash);

  await tx.wait();

  await fetchWishlist();

} catch (err) {
  console.error("ADD ERROR:", err);
  setError("Failed to add wishlist item");
} finally {
  setLoading(false);
}


};


const stakeToWishlistItem = async (index, amount) => {
try {
setLoading(true);
setError("");


  const { contract } = await getSignerAndContract();

  const value = ethers.parseEther(amount.toString());

  console.log("----- STAKE DEBUG -----");
  console.log("Index:", index);
  console.log("ETH:", amount);
  console.log("Wei:", value.toString());

  const tx = await contract.stakeETH(index, {
    value: value
  });

  console.log("Stake tx:", tx.hash);

  await tx.wait();

  await fetchWishlist();

} catch (err) {
  console.error("STAKE ERROR:", err);
  setError("Staking failed");
} finally {
  setLoading(false);
}

};


useEffect(() => {
if (window.ethereum) {
fetchWishlist();
}
}, []);

return (
<WishlistContext.Provider
value={{
wishlistItems,
addWishlistItem,
stakeToWishlistItem,
loading,
error,
}}
>
{children}
</WishlistContext.Provider>
);
};
